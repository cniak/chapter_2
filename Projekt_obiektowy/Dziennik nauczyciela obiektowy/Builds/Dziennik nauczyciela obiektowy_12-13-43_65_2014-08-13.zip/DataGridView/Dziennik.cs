﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Dziennik_nauczyciela_obiektowy.DataGridView
{
    class Dziennik : Lista<uczen_na_lekcji>

    {
    }
}
