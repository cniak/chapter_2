﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Dziennik_nauczyciela_obiektowy
{
    public enum ERodzajZapytania
    {
        wyslij = 0,
        pobierz = 1,
    }
}
