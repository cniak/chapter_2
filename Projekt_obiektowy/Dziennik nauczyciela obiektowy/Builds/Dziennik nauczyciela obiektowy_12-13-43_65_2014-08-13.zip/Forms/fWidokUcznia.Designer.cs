﻿namespace Dziennik_nauczyciela_obiektowy.Forms
{
    partial class fWidokUcznia
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label14 = new System.Windows.Forms.Label();
            this.b_dodaj = new System.Windows.Forms.Button();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.t_imie_dodaj = new System.Windows.Forms.TextBox();
            this.t_nazwisko_dodaj = new System.Windows.Forms.TextBox();
            this.t_nrUcznia_dodaj = new System.Windows.Forms.TextBox();
            this.t_pesel_dodaj = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.t_nrRodzica_dodaj = new System.Windows.Forms.TextBox();
            this.t_email_dodaj = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.b_zapisz = new System.Windows.Forms.Button();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.t_imie_edytuj = new System.Windows.Forms.TextBox();
            this.t_nazwisko_edytuj = new System.Windows.Forms.TextBox();
            this.t_nrUcznia_edytuj = new System.Windows.Forms.TextBox();
            this.t_pesel_edytuj = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.t_nrRodzica_edytuj = new System.Windows.Forms.TextBox();
            this.t_email_edytuj = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.tc_widok.SuspendLayout();
            this.tp_dodaj.SuspendLayout();
            this.tp_edytuj.SuspendLayout();
            this.tp_usun.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // tc_widok
            // 
            this.tc_widok.Location = new System.Drawing.Point(187, 0);
            this.tc_widok.Size = new System.Drawing.Size(598, 279);
            // 
            // tp_dodaj
            // 
            this.tp_dodaj.Controls.Add(this.label14);
            this.tp_dodaj.Controls.Add(this.b_dodaj);
            this.tp_dodaj.Controls.Add(this.tableLayoutPanel1);
            this.tp_dodaj.Size = new System.Drawing.Size(590, 253);
            // 
            // tp_edytuj
            // 
            this.tp_edytuj.Controls.Add(this.label15);
            this.tp_edytuj.Controls.Add(this.b_zapisz);
            this.tp_edytuj.Controls.Add(this.tableLayoutPanel2);
            this.tp_edytuj.Size = new System.Drawing.Size(590, 219);
            // 
            // tp_usun
            // 
            this.tp_usun.Size = new System.Drawing.Size(590, 219);
            // 
            // b_usun1
            // 
            this.b_usun1.Click += new System.EventHandler(this.b_usun1_Click);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(3, 196);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(189, 13);
            this.label14.TabIndex = 6;
            this.label14.Text = "Wymagane pola: imie, nazwisko, pesel";
            // 
            // b_dodaj
            // 
            this.b_dodaj.Location = new System.Drawing.Point(490, 191);
            this.b_dodaj.Name = "b_dodaj";
            this.b_dodaj.Size = new System.Drawing.Size(75, 23);
            this.b_dodaj.TabIndex = 5;
            this.b_dodaj.Text = "Dodaj";
            this.b_dodaj.UseVisualStyleBackColor = true;
            this.b_dodaj.Click += new System.EventHandler(this.b_dodaj_Click);
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 39.81482F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 60.18518F));
            this.tableLayoutPanel1.Controls.Add(this.label1, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.label3, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.t_imie_dodaj, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.t_nazwisko_dodaj, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.t_nrUcznia_dodaj, 1, 11);
            this.tableLayoutPanel1.Controls.Add(this.t_pesel_dodaj, 1, 5);
            this.tableLayoutPanel1.Controls.Add(this.label10, 0, 5);
            this.tableLayoutPanel1.Controls.Add(this.label7, 0, 12);
            this.tableLayoutPanel1.Controls.Add(this.t_nrRodzica_dodaj, 1, 12);
            this.tableLayoutPanel1.Controls.Add(this.t_email_dodaj, 1, 10);
            this.tableLayoutPanel1.Controls.Add(this.label9, 0, 10);
            this.tableLayoutPanel1.Controls.Add(this.label4, 0, 11);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(6, 6);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 13;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 26F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 27F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(559, 179);
            this.tableLayoutPanel1.TabIndex = 4;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(3, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(29, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Imię:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(3, 26);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(56, 13);
            this.label3.TabIndex = 1;
            this.label3.Text = "Nazwisko:";
            // 
            // t_imie_dodaj
            // 
            this.t_imie_dodaj.Location = new System.Drawing.Point(225, 3);
            this.t_imie_dodaj.Name = "t_imie_dodaj";
            this.t_imie_dodaj.Size = new System.Drawing.Size(244, 20);
            this.t_imie_dodaj.TabIndex = 5;
            // 
            // t_nazwisko_dodaj
            // 
            this.t_nazwisko_dodaj.Location = new System.Drawing.Point(225, 29);
            this.t_nazwisko_dodaj.Name = "t_nazwisko_dodaj";
            this.t_nazwisko_dodaj.Size = new System.Drawing.Size(244, 20);
            this.t_nazwisko_dodaj.TabIndex = 6;
            // 
            // t_nrUcznia_dodaj
            // 
            this.t_nrUcznia_dodaj.Location = new System.Drawing.Point(225, 107);
            this.t_nrUcznia_dodaj.Name = "t_nrUcznia_dodaj";
            this.t_nrUcznia_dodaj.Size = new System.Drawing.Size(244, 20);
            this.t_nrUcznia_dodaj.TabIndex = 9;
            // 
            // t_pesel_dodaj
            // 
            this.t_pesel_dodaj.Location = new System.Drawing.Point(225, 55);
            this.t_pesel_dodaj.Name = "t_pesel_dodaj";
            this.t_pesel_dodaj.Size = new System.Drawing.Size(244, 20);
            this.t_pesel_dodaj.TabIndex = 7;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(3, 52);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(36, 13);
            this.label10.TabIndex = 17;
            this.label10.Text = "Pesel:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(3, 131);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(119, 13);
            this.label7.TabIndex = 11;
            this.label7.Text = "Numer telefonu rodzica:";
            // 
            // t_nrRodzica_dodaj
            // 
            this.t_nrRodzica_dodaj.Location = new System.Drawing.Point(225, 134);
            this.t_nrRodzica_dodaj.Name = "t_nrRodzica_dodaj";
            this.t_nrRodzica_dodaj.Size = new System.Drawing.Size(244, 20);
            this.t_nrRodzica_dodaj.TabIndex = 10;
            // 
            // t_email_dodaj
            // 
            this.t_email_dodaj.Location = new System.Drawing.Point(225, 81);
            this.t_email_dodaj.Name = "t_email_dodaj";
            this.t_email_dodaj.Size = new System.Drawing.Size(244, 20);
            this.t_email_dodaj.TabIndex = 8;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(3, 78);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(67, 13);
            this.label9.TabIndex = 14;
            this.label9.Text = "Adres e-mail:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(3, 104);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(116, 13);
            this.label4.TabIndex = 19;
            this.label4.Text = "Numer telefonu ucznia:";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(3, 196);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(189, 13);
            this.label15.TabIndex = 7;
            this.label15.Text = "Wymagane pola: imie, nazwisko, pesel";
            // 
            // b_zapisz
            // 
            this.b_zapisz.Location = new System.Drawing.Point(490, 191);
            this.b_zapisz.Name = "b_zapisz";
            this.b_zapisz.Size = new System.Drawing.Size(75, 23);
            this.b_zapisz.TabIndex = 6;
            this.b_zapisz.Text = "Zapisz";
            this.b_zapisz.UseVisualStyleBackColor = true;
            this.b_zapisz.Click += new System.EventHandler(this.b_zapisz_Click);
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 2;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 39.81482F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 60.18518F));
            this.tableLayoutPanel2.Controls.Add(this.label5, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.label6, 0, 1);
            this.tableLayoutPanel2.Controls.Add(this.t_imie_edytuj, 1, 0);
            this.tableLayoutPanel2.Controls.Add(this.t_nazwisko_edytuj, 1, 1);
            this.tableLayoutPanel2.Controls.Add(this.t_nrUcznia_edytuj, 1, 11);
            this.tableLayoutPanel2.Controls.Add(this.t_pesel_edytuj, 1, 5);
            this.tableLayoutPanel2.Controls.Add(this.label8, 0, 5);
            this.tableLayoutPanel2.Controls.Add(this.label11, 0, 12);
            this.tableLayoutPanel2.Controls.Add(this.t_nrRodzica_edytuj, 1, 12);
            this.tableLayoutPanel2.Controls.Add(this.t_email_edytuj, 1, 10);
            this.tableLayoutPanel2.Controls.Add(this.label12, 0, 10);
            this.tableLayoutPanel2.Controls.Add(this.label13, 0, 11);
            this.tableLayoutPanel2.Location = new System.Drawing.Point(6, 6);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 13;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 26F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 27F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(559, 179);
            this.tableLayoutPanel2.TabIndex = 5;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(3, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(29, 13);
            this.label5.TabIndex = 0;
            this.label5.Text = "Imię:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(3, 26);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(56, 13);
            this.label6.TabIndex = 1;
            this.label6.Text = "Nazwisko:";
            // 
            // t_imie_edytuj
            // 
            this.t_imie_edytuj.Location = new System.Drawing.Point(225, 3);
            this.t_imie_edytuj.Name = "t_imie_edytuj";
            this.t_imie_edytuj.Size = new System.Drawing.Size(244, 20);
            this.t_imie_edytuj.TabIndex = 5;
            // 
            // t_nazwisko_edytuj
            // 
            this.t_nazwisko_edytuj.Location = new System.Drawing.Point(225, 29);
            this.t_nazwisko_edytuj.Name = "t_nazwisko_edytuj";
            this.t_nazwisko_edytuj.Size = new System.Drawing.Size(244, 20);
            this.t_nazwisko_edytuj.TabIndex = 6;
            // 
            // t_nrUcznia_edytuj
            // 
            this.t_nrUcznia_edytuj.Location = new System.Drawing.Point(225, 107);
            this.t_nrUcznia_edytuj.Name = "t_nrUcznia_edytuj";
            this.t_nrUcznia_edytuj.Size = new System.Drawing.Size(244, 20);
            this.t_nrUcznia_edytuj.TabIndex = 15;
            // 
            // t_pesel_edytuj
            // 
            this.t_pesel_edytuj.Location = new System.Drawing.Point(225, 55);
            this.t_pesel_edytuj.Name = "t_pesel_edytuj";
            this.t_pesel_edytuj.Size = new System.Drawing.Size(244, 20);
            this.t_pesel_edytuj.TabIndex = 18;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(3, 52);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(36, 13);
            this.label8.TabIndex = 17;
            this.label8.Text = "Pesel:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(3, 131);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(119, 13);
            this.label11.TabIndex = 11;
            this.label11.Text = "Numer telefonu rodzica:";
            // 
            // t_nrRodzica_edytuj
            // 
            this.t_nrRodzica_edytuj.Location = new System.Drawing.Point(225, 134);
            this.t_nrRodzica_edytuj.Name = "t_nrRodzica_edytuj";
            this.t_nrRodzica_edytuj.Size = new System.Drawing.Size(244, 20);
            this.t_nrRodzica_edytuj.TabIndex = 10;
            // 
            // t_email_edytuj
            // 
            this.t_email_edytuj.Location = new System.Drawing.Point(225, 81);
            this.t_email_edytuj.Name = "t_email_edytuj";
            this.t_email_edytuj.Size = new System.Drawing.Size(244, 20);
            this.t_email_edytuj.TabIndex = 0;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(3, 78);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(67, 13);
            this.label12.TabIndex = 14;
            this.label12.Text = "Adres e-mail:";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(3, 104);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(116, 13);
            this.label13.TabIndex = 19;
            this.label13.Text = "Numer telefonu ucznia:";
            // 
            // fWidokUcznia
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(785, 279);
            this.Name = "fWidokUcznia";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "fWidokUcznia";
            this.Load += new System.EventHandler(this.fWidokUcznia_Load);
            this.tc_widok.ResumeLayout(false);
            this.tp_dodaj.ResumeLayout(false);
            this.tp_dodaj.PerformLayout();
            this.tp_edytuj.ResumeLayout(false);
            this.tp_edytuj.PerformLayout();
            this.tp_usun.ResumeLayout(false);
            this.tp_usun.PerformLayout();
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Button b_dodaj;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox t_imie_dodaj;
        private System.Windows.Forms.TextBox t_nazwisko_dodaj;
        private System.Windows.Forms.TextBox t_nrUcznia_dodaj;
        private System.Windows.Forms.TextBox t_pesel_dodaj;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox t_nrRodzica_dodaj;
        private System.Windows.Forms.TextBox t_email_dodaj;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Button b_zapisz;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox t_imie_edytuj;
        private System.Windows.Forms.TextBox t_nazwisko_edytuj;
        private System.Windows.Forms.TextBox t_nrUcznia_edytuj;
        private System.Windows.Forms.TextBox t_pesel_edytuj;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox t_nrRodzica_edytuj;
        private System.Windows.Forms.TextBox t_email_edytuj;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
    }
}