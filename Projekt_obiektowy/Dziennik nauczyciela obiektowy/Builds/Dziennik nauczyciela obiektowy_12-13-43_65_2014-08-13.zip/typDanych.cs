﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Dziennik_nauczyciela_obiektowy
{
    public enum EtypDanych
    {
        ocena = 0,
        obecnosc = 1,
        uwagi = 2
    }
}
